1:"$Sreact.fragment"
2:I[9875,["9875","static/chunks/9875-e99434e12274ca22.js","5085","static/chunks/app/admin/seo/new/page-44181d675cb341cf.js"],"default"]
3:I[484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"min-h-screen bg-gray-50 py-8","children":["$","div",null,{"className":"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8","children":[["$","div",null,{"className":"mb-8","children":[["$","h1",null,{"className":"text-3xl font-bold text-gray-900","children":"Add SEO Metadata"}],["$","p",null,{"className":"text-gray-600 mt-2","children":"Create SEO metadata for a new page"}]]}],["$","$L2",null,{}]]}]}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"eOxki8za1Bfo7DucnpdZ-"}
5:null
