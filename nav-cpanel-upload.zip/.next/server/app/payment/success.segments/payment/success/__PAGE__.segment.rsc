1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[6880,["8500","static/chunks/8500-3953cc33eeceb44e.js","8179","static/chunks/app/payment/success/page-105d2813508acef8.js"],"default"]
4:I[484,[],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-screen flex items-center justify-center","children":"Loading payment confirmation..."}],"children":["$","$L3",null,{}]}],null,["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"eOxki8za1Bfo7DucnpdZ-"}
5:null
