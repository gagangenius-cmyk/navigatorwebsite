1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","div",null,{"className":"min-h-screen","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"eOxki8za1Bfo7DucnpdZ-"}
