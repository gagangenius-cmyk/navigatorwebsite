import { Metadata } from 'next'
import { ReactNode } from 'react'
import { getBlogPost } from '@/lib/blogData'
import { buildPageMetadata, buildAuthorPersonSchema, siteUrl, siteName } from '@/lib/marketingSeo'
import JsonLd from '@/components/seo/JsonLd'

interface BlogPostLayoutProps {
  children: ReactNode
  params: Promise<{
    id: string
  }>
}

export default async function BlogPostLayout({ children, params }: BlogPostLayoutProps) {
  const { id } = await params
  const post = getBlogPost(id)

  return (
    <div className="min-h-screen">
      {post && (
        <>
          <JsonLd data={{
            '@context': 'https://schema.org',
            '@type': 'Article',
            '@id': `${siteUrl}/blog/${post.id}#article`,
            headline: post.title,
            description: post.excerpt,
            author: {
              '@type': 'Person',
              '@id': `${siteUrl}/blog/${post.id}#author`,
              name: post.author,
              description: post.authorBio,
              image: undefined,
              worksFor: {
                '@type': 'Organization',
                name: siteName,
              },
            },
            datePublished: post.date,
            dateModified: post.date,
            mainEntityOfPage: {
              '@type': 'WebPage',
              '@id': `${siteUrl}/blog/${post.id}`,
            },
            publisher: {
              '@type': 'Organization',
              '@id': `${siteUrl}/#organization`,
              name: siteName,
              logo: {
                '@type': 'ImageObject',
                url: `${siteUrl}/img/logo/logonew.png`,
              },
            },
            image: {
              '@type': 'ImageObject',
              url: `${siteUrl}/img/logo/logonew.png`,
              width: 1200,
              height: 630,
            },
            wordCount: post.sections.reduce((count, s) => count + s.body.split(/\s+/).length + s.heading.split(/\s+/).length + (s.bullets?.reduce((b, bullet) => b + bullet.split(/\s+/).length, 0) ?? 0), 0),
            articleSection: post.category,
            isPartOf: {
              '@id': `${siteUrl}/#website`,
            },
          }} />
          <JsonLd data={buildAuthorPersonSchema(post.author, post.authorBio ?? '', undefined)} />
          <JsonLd data={{
            '@context': 'https://schema.org',
            '@type': 'BreadcrumbList',
            itemListElement: [
              { '@type': 'ListItem', position: 1, name: 'Home', item: `${siteUrl}/` },
              { '@type': 'ListItem', position: 2, name: 'Blog', item: `${siteUrl}/blog` },
              { '@type': 'ListItem', position: 3, name: post.title, item: `${siteUrl}/blog/${post.id}` },
            ],
          }} />
          {post.faqs.length > 0 && (
            <JsonLd data={{
              '@context': 'https://schema.org',
              '@type': 'FAQPage',
              mainEntity: post.faqs.map(faq => ({
                '@type': 'Question',
                name: faq.question,
                acceptedAnswer: {
                  '@type': 'Answer',
                  text: faq.answer,
                },
              })),
            }} />
          )}
        </>
      )}
      {children}
    </div>
  )
}

export async function generateMetadata({ params }: BlogPostLayoutProps): Promise<Metadata> {
  const { id } = await params
  const post = getBlogPost(id);

  return buildPageMetadata(
    {
      path: `/blog/${id}`,
      title: post ? post.title : `Immigration Guide | ${id.replace(/-/g, ' ')}`,
      description:
        post?.excerpt ??
        'Read a Navigator Immigration guide covering visa pathways, document planning, and immigration questions for clients in Dubai and beyond.',
      keywords: post?.tags ?? ['immigration guide', 'visa guide', 'Navigator Immigration blog'],
      h1: post?.title ?? id,
      answer:
        post?.answer ??
        'This immigration guide explains a practical visa or migration topic and links readers to the most relevant service page for consultation support.',
      breadcrumbs: [
        { name: 'Home', path: '/' },
        { name: 'Blog', path: '/blog' },
        { name: post?.title ?? id, path: `/blog/${id}` },
      ],
      faqs: [],
      relatedLinks: [],
      trustPoints: [],
      pageType: 'Article',
    },
    undefined,
      post
        ? {
            publishedTime: new Date(post.date).toISOString(),
            modifiedTime: new Date(post.date).toISOString(),
          }
        : undefined
  )
}
