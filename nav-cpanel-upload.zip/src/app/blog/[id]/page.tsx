import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, Calendar, Share2, Heart, MessageCircle } from 'lucide-react';
import JsonLd from '@/components/seo/JsonLd';
import { FaqSection, RelatedLinksSection } from '@/components/seo/PageSeoSections';
import { getBlogPost, getAllBlogPosts } from '@/lib/blogData';
import { formatStableDate } from '@/lib/formatting';
import {
  buildSpeakableSchema,
  coreSeoPages,
} from '@/lib/marketingSeo';

export default async function BlogPost({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const blogPost = getBlogPost(id);

  if (!blogPost) {
    notFound();
  }

  const allPosts = getAllBlogPosts();
  const relatedPosts = blogPost.relatedIds
    .map((relatedId) => allPosts.find((post) => post.id === relatedId))
    .filter((post): post is NonNullable<typeof post> => Boolean(post));
  const speakableSchema = buildSpeakableSchema('#site-content');

  return (
    <div className="min-h-screen bg-[#f5f5dc]">
      <JsonLd data={speakableSchema} />
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Link
              href="/blog"
              className="inline-flex items-center text-[#436175] hover:text-[#585a5e] mb-8"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Link>

            <article>
              <header className="mb-8">
                <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                  <span className="bg-[#436175]/10 text-[#436175] px-3 py-1 rounded-full font-medium">
                    {blogPost.category}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{formatStableDate(blogPost.date)}</span>
                  </div>
                  <span>{blogPost.readTime}</span>
                </div>
                
                <h1 className="text-4xl lg:text-5xl font-bold text-[#436175] mb-6">
                  {blogPost.title}
                </h1>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-gray-400 text-xs font-bold">
                      {blogPost.author.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-[#436175]">{blogPost.author}</p>
                      <p className="text-sm text-[#585a5e]">Immigration Consultant</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <button className="flex items-center space-x-2 text-[#585a5e] hover:text-blue-600">
                      <Heart className="w-5 h-5" />
                      <span>Like</span>
                    </button>
                    <button className="flex items-center space-x-2 text-[#585a5e] hover:text-blue-600">
                      <Share2 className="w-5 h-5" />
                      <span>Share</span>
                    </button>
                    <button className="flex items-center space-x-2 text-[#585a5e] hover:text-blue-600">
                      <MessageCircle className="w-5 h-5" />
                      <span>Comment</span>
                    </button>
                  </div>
                </div>
              </header>

              <div className="prose prose-lg max-w-none">
                <div className="rounded-2xl bg-[#f8f4ea] p-6 text-gray-700 leading-relaxed">
                  <p>{blogPost.answer}</p>
                </div>
                <div className="mt-10 space-y-8 text-gray-700">
                  {blogPost.sections.map((section) => (
                    <section key={section.heading}>
                      <h2 className="mb-3 text-2xl font-bold text-[#436175]">{section.heading}</h2>
                      <p>{section.body}</p>
                      {section.bullets?.length ? (
                        <ul className="mt-4 space-y-2">
                          {section.bullets.map((bullet) => (
                            <li key={bullet}>• {bullet}</li>
                          ))}
                        </ul>
                      ) : null}
                    </section>
                  ))}
                </div>
              </div>

              <footer className="mt-12 pt-8 border-t">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="text-[#585a5e]">Tags:</span>
                    <div className="flex space-x-2">
                      {blogPost.tags.map((tag) => (
                        <span
                          key={tag}
                          className="bg-gray-100 text-[#585a5e] px-3 py-1 rounded-full text-sm"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </footer>
            </article>

            <section className="mt-16">
              <h2 className="text-2xl font-bold text-[#436175] mb-8">Related Articles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {relatedPosts.map((post) => (
                  <article key={post.id} className="bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow">
                    <h3 className="text-lg font-semibold text-[#436175] mb-2 hover:text-blue-600">
                      <Link href={`/blog/${post.id}`}>
                        {post.title}
                      </Link>
                    </h3>
                    <p className="text-[#585a5e]">{post.excerpt}</p>
                  </article>
                ))}
              </div>
            </section>

            <div className="mt-16">
              <FaqSection items={blogPost.faqs} />
            </div>

            <section className="mt-16 bg-blue-50 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-[#436175] mb-4">Need Help with Your Immigration?</h2>
              <p className="text-[#585a5e] mb-6">
                Our Dubai team can help you turn this guide into an action plan for PR, study, work, visit, or business immigration.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center px-6 py-3 border-2 border-[rgb(247,55,24)] text-[rgb(247,55,24)] font-semibold rounded-lg hover:bg-[rgb(247,55,24)] hover:text-white transition-colors"
              >
                Schedule Consultation
                <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
              </Link>
            </section>

            <div className="mt-16">
              <RelatedLinksSection links={coreSeoPages.blog.relatedLinks} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
