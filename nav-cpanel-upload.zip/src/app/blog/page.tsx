import { getAllBlogPosts } from '@/lib/blogData';
import type { BlogPost } from '@/lib/blogData';
import BlogClient from './_components/BlogClient';

export default function BlogPage() {
  const posts: BlogPost[] = getAllBlogPosts();
  return <BlogClient posts={posts} />;
}
