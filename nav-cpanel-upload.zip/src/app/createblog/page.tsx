"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const BLOG_CREATE_SECRET = process.env.BLOG_CREATE_SECRET || '';

const KNOWN_CATEGORIES = [
  'Canada Immigration',
  'Australia Immigration',
  'Europe Work',
  'Student Visas',
  'Visit Visas',
  'Other Blogs',
];

const initialSection = {
  heading: '',
  body: '',
  bullets: [''],
};

const initialFaq = {
  question: '',
  answer: '',
};

export default function CreateBlog() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    title: '',
    excerpt: '',
    author: '',
    authorBio: '',
    date: new Date().toISOString().split('T')[0],
    category: '',
    readTime: '',
    answer: '',
    sections: [initialSection],
    faqs: [initialFaq],
    tags: [''],
    relatedIds: [''],
  });

  const [secretCode, setSecretCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (error) setError('');
  };

  const handleArrayChange = (field: string, index: number, value: string) => {
    setFormData(prev => {
      const newArray = [...(prev[field as keyof typeof prev] as string[])];
      newArray[index] = value;
      return { ...prev, [field]: newArray };
    });
  };

  const addArrayItem = (field: string) => {
    setFormData(prev => {
      const newArray = [...(prev[field as keyof typeof prev] as string[])];
      newArray.push('');
      return { ...prev, [field]: newArray };
    });
  };

  const removeArrayItem = (field: string, index: number) => {
    setFormData(prev => {
      const newArray = [...(prev[field as keyof typeof prev] as string[])];
      newArray.splice(index, 1);
      return { ...prev, [field]: newArray };
    });
  };

  const handleSectionChange = (index: number, field: string, value: string) => {
    setFormData(prev => {
      const newSections = [...prev.sections];
      newSections[index] = { ...newSections[index], [field]: value };
      return { ...prev, sections: newSections };
    });
  };

  const handleSectionBulletChange = (sectionIndex: number, bulletIndex: number, value: string) => {
    setFormData(prev => {
      const newSections = [...prev.sections];
      const newBullets = [...newSections[sectionIndex].bullets!];
      newBullets[bulletIndex] = value;
      newSections[sectionIndex] = { ...newSections[sectionIndex], bullets: newBullets };
      return { ...prev, sections: newSections };
    });
  };

  const addSection = () => {
    setFormData(prev => ({ ...prev, sections: [...prev.sections, initialSection] }));
  };

  const removeSection = (index: number) => {
    setFormData(prev => {
      const newSections = prev.sections.filter((_, i) => i !== index);
      return { ...prev, sections: newSections };
    });
  };

  const handleFaqChange = (index: number, field: string, value: string) => {
    setFormData(prev => {
      const newFaqs = [...prev.faqs];
      newFaqs[index] = { ...newFaqs[index], [field]: value };
      return { ...prev, faqs: newFaqs };
    });
  };

  const addFaq = () => {
    setFormData(prev => ({ ...prev, faqs: [...prev.faqs, initialFaq] }));
  };

  const removeFaq = (index: number) => {
    setFormData(prev => {
      const newFaqs = prev.faqs.filter((_, i) => i !== index);
      return { ...prev, faqs: newFaqs };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    if (secretCode !== BLOG_CREATE_SECRET) {
      setError('Invalid secret code');
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch('/api/blog/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          secret: secretCode,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create blog');
      }

      setSuccess(true);
      setTimeout(() => {
        router.push('/blog');
      }, 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create blog');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f5dc] py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-[#436175] mb-8 text-center">
            Create New Blog Post
          </h1>

          {success && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
              Blog created successfully! Redirecting to blog page...
            </div>
          )}

          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Excerpt *
                </label>
                <textarea
                  name="excerpt"
                  value={formData.excerpt}
                  onChange={handleInputChange}
                  required
                  rows={3}
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Author *
                </label>
                <input
                  type="text"
                  name="author"
                  value={formData.author}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Author Bio *
                </label>
                <textarea
                  name="authorBio"
                  value={formData.authorBio}
                  onChange={handleInputChange}
                  required
                  rows={3}
                  placeholder="Brief bio about the author (SEO: used in Person schema)"
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Date *
                </label>
                <input
                  type="date"
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Category *
                </label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                >
                  <option value="">Select a category</option>
                  {KNOWN_CATEGORIES.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#436175] mb-2">
                  Read Time *
                </label>
                <input
                  type="text"
                  name="readTime"
                  value={formData.readTime}
                  onChange={handleInputChange}
                  required
                  placeholder="e.g., 5 min read"
                  className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#436175] mb-2">
                Answer *
              </label>
              <textarea
                name="answer"
                value={formData.answer}
                onChange={handleInputChange}
                required
                rows={4}
                className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#436175] mb-2">
                Tags (comma-separated) *
              </label>
              <input
                type="text"
                value={formData.tags.filter(t => t).join(', ')}
                onChange={(e) => {
                  const tags = e.target.value.split(',').map(t => t.trim()).filter(t => t);
                  setFormData(prev => ({ ...prev, tags }));
                }}
                required
                placeholder="e.g., Canada PR, Express Entry, Dubai"
                className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[#436175] mb-2">
                Related IDs (comma-separated) *
              </label>
              <input
                type="text"
                value={formData.relatedIds.filter(id => id).join(', ')}
                onChange={(e) => {
                  const relatedIds = e.target.value.split(',').map(id => id.trim()).filter(id => id);
                  setFormData(prev => ({ ...prev, relatedIds }));
                }}
                required
                placeholder="e.g., canada-pr-from-dubai, express-entry-vs-pnp"
                className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-[#436175]">Sections</h2>
                <button
                  type="button"
                  onClick={addSection}
                  className="px-4 py-2 bg-[#436175] text-white rounded-lg hover:bg-[#585a5e] transition-colors"
                >
                  Add Section
                </button>
              </div>

              {formData.sections.map((section, sectionIndex) => (
                <div key={sectionIndex} className="bg-gray-50 p-4 rounded-lg border border-light-brown-grey">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium text-[#436175]">Section {sectionIndex + 1}</h3>
                    <button
                      type="button"
                      onClick={() => removeSection(sectionIndex)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Remove
                    </button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-[#436175] mb-1">
                        Heading
                      </label>
                      <input
                        type="text"
                        value={section.heading}
                        onChange={(e) => handleSectionChange(sectionIndex, 'heading', e.target.value)}
                        className="w-full px-3 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#436175] mb-1">
                        Body
                      </label>
                      <textarea
                        value={section.body}
                        onChange={(e) => handleSectionChange(sectionIndex, 'body', e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#436175] mb-1">
                        Bullets (one per line)
                      </label>
                      {section.bullets?.map((bullet, bulletIndex) => (
                        <div key={bulletIndex} className="flex gap-2 mb-2">
                          <input
                            type="text"
                            value={bullet}
                            onChange={(e) => handleSectionBulletChange(sectionIndex, bulletIndex, e.target.value)}
                            className="flex-1 px-3 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                          />
                          <button
                            type="button"
                            onClick={() => removeArrayItem('sections', sectionIndex)}
                            className="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          const newSections = [...formData.sections];
                          newSections[sectionIndex] = { ...newSections[sectionIndex], bullets: [...(newSections[sectionIndex].bullets || []), ''] };
                          setFormData(prev => ({ ...prev, sections: newSections }));
                        }}
                        className="px-3 py-2 bg-green-100 text-green-600 rounded-lg hover:bg-green-200"
                      >
                        Add Bullet
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-[#436175]">FAQs</h2>
                <button
                  type="button"
                  onClick={addFaq}
                  className="px-4 py-2 bg-[#436175] text-white rounded-lg hover:bg-[#585a5e] transition-colors"
                >
                  Add FAQ
                </button>
              </div>

              {formData.faqs.map((faq, faqIndex) => (
                <div key={faqIndex} className="bg-gray-50 p-4 rounded-lg border border-light-brown-grey">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-medium text-[#436175]">FAQ {faqIndex + 1}</h3>
                    <button
                      type="button"
                      onClick={() => removeFaq(faqIndex)}
                      className="text-red-600 hover:text-red-800"
                    >
                      Remove
                    </button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-[#436175] mb-1">
                        Question
                      </label>
                      <input
                        type="text"
                        value={faq.question}
                        onChange={(e) => handleFaqChange(faqIndex, 'question', e.target.value)}
                        className="w-full px-3 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#436175] mb-1">
                        Answer
                      </label>
                      <textarea
                        value={faq.answer}
                        onChange={(e) => handleFaqChange(faqIndex, 'answer', e.target.value)}
                        rows={2}
                        className="w-full px-3 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-[#436175] mb-2">
                Secret Code *
              </label>
              <input
                type="password"
                value={secretCode}
                onChange={(e) => setSecretCode(e.target.value)}
                required
                placeholder="Enter your secret code"
                className="w-full px-4 py-2 border border-light-brown-grey rounded-lg focus:outline-none focus:ring-2 focus:ring-[#436175]"
              />
              <p className="text-xs text-gray-500 mt-1">
                The secret code is configured in the environment variables.
              </p>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-8 py-3 bg-orange-600 text-white font-semibold rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
              >
                {isSubmitting ? 'Creating...' : 'Submit Blog'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}