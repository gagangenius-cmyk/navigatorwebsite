import type { Metadata } from "next";
import { Poppins, Montserrat } from "next/font/google";
import "./globals.css";
import TopBar from "../components/TopBar";
import MainHeader from "../components/MainHeader";
import Footer from "../components/Footer";
import DeferredChatBot from "../components/DeferredChatBot";
import JsonLd from '@/components/seo/JsonLd';
import {
  buildLocalBusinessSchema,
  buildOrganizationSchema,
  buildWebsiteSchema,
  defaultOgImage,
  siteName,
  siteUrl,
} from '@/lib/marketingSeo';
import { siteTestimonials } from '@/lib/testimonialsData';

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-poppins",
});

const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-montserrat",
});


export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Navigator Immigration | Immigration Consultants in Dubai',
    template: '%s | Navigator Immigration',
  },
  description:
    'Navigator Immigration is a Dubai-based immigration consultancy for Canada PR, Australia PR, student visas, Europe work permits, visit visas, and business immigration.',
  keywords: [
    'immigration consultants in Dubai',
    'visa consultants in Dubai',
    'Canada PR consultants in Dubai',
    'Australia PR consultants in Dubai',
    'student visa consultants in Dubai',
    'Europe work permit consultants in Dubai',
    'business immigration consultants Dubai',
    'Navigator Immigration',
  ],
  authors: [{ name: siteName }],
  creator: siteName,
  publisher: siteName,
  robots: 'index, follow',
  openGraph: {
    title: 'Navigator Immigration | Immigration Consultants in Dubai',
    description:
      'Navigator Immigration is a Dubai-based immigration consultancy for Canada PR, Australia PR, student visas, Europe work permits, visit visas, and business immigration.',
    url: `${siteUrl}/`,
    siteName,
    type: 'website',
    locale: 'en_US',
    images: [
      {
        url: defaultOgImage,
        width: 1200,
        height: 630,
        alt: 'Navigator Immigration in Dubai',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Navigator Immigration | Immigration Consultants in Dubai',
    description:
      'Navigator Immigration offers Canada PR, Australia PR, student visas, Europe work permits, visit visas, and business immigration guidance from Dubai.',
    images: [defaultOgImage],
  },
  alternates: {
    canonical: `${siteUrl}/`,
    languages: {
      'en': `${siteUrl}/`,
      'x-default': `${siteUrl}/`,
    },
  },
  icons: {
    icon: '/title.png',
    shortcut: '/title.png',
    apple: '/title.png',
  },
  verification: {
    google: 'ftVAc0-q66Z6wB89bjjXrTLXJ1hFI9OfPQAnpDT5im0',
    yandex: 'yandex-verification=your-verification-code'
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${poppins.variable} ${montserrat.variable}`}
      suppressHydrationWarning
    >
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#436175" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />

        {/* Strip bis_skin_checked attributes added by browser extensions before React hydrates */}
        <script suppressHydrationWarning dangerouslySetInnerHTML={{
          __html: `
            try {
              var bisRemover = new MutationObserver(function() {
                var els = document.querySelectorAll('[bis_skin_checked]');
                for (var i = 0; i < els.length; i++) {
                  els[i].removeAttribute('bis_skin_checked');
                }
              });
              bisRemover.observe(document.documentElement, {attributes: true, subtree: true, attributeFilter: ['bis_skin_checked']});
            } catch(e) {}
          `
        }} />

        {/* Google Analytics */}
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-LP61V70NXQ" suppressHydrationWarning />
        <script
          suppressHydrationWarning
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-LP61V70NXQ');
            `,
          }}
        />
      </head>
      <body className="font-sans antialiased" suppressHydrationWarning>
        <JsonLd data={buildOrganizationSchema()} />
        <JsonLd data={buildLocalBusinessSchema(siteTestimonials)} />
        <JsonLd data={buildWebsiteSchema()} />
        <TopBar />
        <MainHeader />
        <div id="site-content"  >{children}</div>
        <Footer />
        <DeferredChatBot />
      </body>
    </html>
  );
}
