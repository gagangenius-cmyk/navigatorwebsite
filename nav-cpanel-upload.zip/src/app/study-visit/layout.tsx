import { Metadata } from 'next'
import { ReactNode } from 'react'

export const metadata: Metadata = {
  title: "Study Visit Programs Canada, Australia, UK | Educational Travel & Student Tours | Navigator Immigration",
  description: "Combined study and visit programs for international students. Short-term educational travel, language courses, and cultural exchange programs. 99% program placement success.",
  keywords: [
    "study visit Canada",
    "educational travel",
    "student exchange program",
    "language course abroad",
    "cultural exchange",
    "short-term study program",
    "study tour",
    "educational tourism",
    "student visitor visa",
    "Navigator Immigration"
  ],
  authors: [{ name: "Navigator Immigration" }],
  creator: "Navigator Immigration",
  robots: "index, follow",
  openGraph: {
    title: "Study Visit Programs - Educational Travel & Cultural Exchange | Navigator Immigration",
    description: "Combined study and visit programs for international students. 99% placement success for educational travel and cultural exchange.",
    url: 'https://navigatorglobals.com/study-visit',
    type: 'website',
    locale: 'en_US',
    images: [
      {
        url: '/img/logo/logo.png',
        width: 1200,
        height: 630,
        alt: 'Study Visit Programs - Navigator Immigration',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Study Visit Programs - 99% Placement Success',
    description: 'Combined study and visit programs for international students. Educational travel and cultural exchange programs.',
    images: ['/img/logo/logo.png'],
  },
  alternates: {
    canonical: 'https://navigatorglobals.com/study-visit',
  },
};

export default function StudyVisitLayout({
  children,
}: {
  children: ReactNode
}) {
  return (
    <div className="min-h-screen">
      {children}
    </div>
  )
}
